# Learn Real World AngularJS Step By Step by CodeCraft
http://codecraftpro.com

## Section 4 - Deep dive into scope

# Folders
./libs/ - The required libraries for all lectures in this course.
lesson1 - Starter template for lecture 1
lesson2 - Starter template for lecture 2
lesson3 - Starter template for lecture 3
completed - The completed application for this section